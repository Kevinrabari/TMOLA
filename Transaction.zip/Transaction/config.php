<?php

// Product Details 
// Minimum amount is $0.50 US 
$itemName = "Demo Product";
$itemPrice = 25;
$currency = "USD";

/* Stripe API configuration 
 * Remember to switch to your live publishable and secret key in production! 
 * See your keys here: https://dashboard.stripe.com/account/apikeys 
 */
define('STRIPE_API_KEY', 'sk_test_51MxBgcIPSWP0x6U1hl6AtsUCXMFNAoSLaP2YTPXeZMOyUMC1vDGeN5xcYMY5XFGNlgtNMwd9NNAjvKI3ysLgJFCR00w1zG8SZd');
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51MxBgcIPSWP0x6U18n1AEsj5VqTBIoUoiPByIP2i1p0YcxdMjKzH93Gb3CxsIeaDpeQmlRX5VbkM3PVJS4oxxfVW003DcYwZzs');

// Database configuration  
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'wordpress');
define('DB_PASSWORD', '12345');
define('DB_NAME', 'TMOLA');

?>