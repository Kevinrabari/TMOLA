// Stripe JS library
<script src="https://js.stripe.com/v3/"></script>;
